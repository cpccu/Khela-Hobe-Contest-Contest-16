#include<bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int X, Y;
        cin >> X >> Y;
        cout << (X < Y ? "FIRST" : (Y < X ? "SECOND" : "ANY")) << endl;
    }
    return 0;
}
