#include<bits/stdc++.h>
using namespace std;

int main() {
    int X, N, M;
    cin >> X >> N >> M;
    cout << ((X + M >= N) ? "YES" : "NO") << endl;
    return 0;
}
