int main(){
    int x,m,n,res;
    scanf("%d %d %d",&x,&m,&n);
    res = x + n;
    if(res > m){
        printf("\nYES");
    }else{ printf("\nNO");
    }

return 0;
}