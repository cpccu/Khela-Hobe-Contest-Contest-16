#include<bits/stdc++.h>
using namespace std;

int main() {
    int T;
    cin >> T;
    while (T--) {
        int X;
        cin >> X;
        cout << (X > 30 ? "YES" : "NO") << endl;
    }
    return 0;
}
