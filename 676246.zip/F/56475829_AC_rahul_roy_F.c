#include <stdio.h>
#include <string.h>

int main() {
    int t;
    scanf("%d",&t);
    while (t--)
    {
        int n;
        scanf("%d",&n);
        printf((n>30) ? "YES": "NO");
        printf("\n");
    }
    
    
    
    return 0;
}